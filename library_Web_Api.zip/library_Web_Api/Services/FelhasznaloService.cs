﻿using library_Web_Api.Models;
using System.Collections.Generic;
using System.Linq;

namespace library_Web_Api.Services
{
    public class FelhasznaloService
    {
        private readonly LibraryContext _context;

        public FelhasznaloService(LibraryContext context)
        {
            _context = context;
        }

        // Hozzáad egy új felhasználót az adatbázishoz
        public void AddFelhasznalo(Felhasznalo newFelhasznalo)
        {
            _context.Felhasznalos.Add(newFelhasznalo);
            _context.SaveChanges();
        }

        // Lekér egy felhasználót azonosító alapján
        public Felhasznalo? GetFelhasznaloById(uint id)
        {
            return _context.Felhasznalos.Find(id);
        }

        // Lekér az összes felhasználót
        public IEnumerable<Felhasznalo> GetAllFelhasznalok()
        {
            return _context.Felhasznalos.ToList();
        }

        // Frissít egy meglévő felhasználót
        public void UpdateFelhasznalo(Felhasznalo felhasznalo)
        {
            _context.Felhasznalos.Update(felhasznalo);
            _context.SaveChanges();
        }

        // Töröl egy felhasználót az adatbázisból
        public void DeleteFelhasznalo(uint id)
        {
            var felhasznalo = _context.Felhasznalos.Find(id);
            if (felhasznalo != null)
            {
                _context.Felhasznalos.Remove(felhasznalo);
                _context.SaveChanges();
            }
        }

    }
}
