﻿using library_Web_Api.Models;
using System.Collections.Generic;
using System.Linq;

namespace library_Web_Api.Services
{
    public class KonyvService
    {
        private readonly LibraryContext _context;

        public KonyvService(LibraryContext context)
        {
            _context = context;
        }

        // Hozzáad egy új könyvet az adatbázishoz
        public void AddKonyv(Konyv newKonyv)
        {
            _context.Konyvs.Add(newKonyv);
            _context.SaveChanges();
        }

        // Lekér egy könyvet azonosító alapján
        public Konyv? GetKonyvById(uint id)
        {
            return _context.Konyvs.Find(id);
        }

        // Lekér az összes könyvet
        public IEnumerable<Konyv> GetAllKonyvek()
        {
            return _context.Konyvs.ToList();
        }

        // Frissít egy meglévő könyvet
        public void UpdateKonyv(Konyv konyv)
        {
            _context.Konyvs.Update(konyv);
            _context.SaveChanges();
        }

        // Töröl egy könyvet az adatbázisból
        public void DeleteKonyv(uint id)
        {
            var konyv = _context.Konyvs.Find(id);
            if (konyv != null)
            {
                _context.Konyvs.Remove(konyv);
                _context.SaveChanges();
            }
        }
    }
}
