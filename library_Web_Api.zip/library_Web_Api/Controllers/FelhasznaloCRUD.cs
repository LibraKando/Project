﻿using library_Web_Api.Models;

namespace library_Web_Api.Controllers
{
    public class FelhasznaloCRUD
    {
        private LibraryContext _context;

        public FelhasznaloCRUD(LibraryContext context)
        {
            _context = context;
        }

        // Create (Felhasználó létrehozása)
        public void AddFelhasznalo(Felhasznalo newFelhasznalo)
        {
            _context.Felhasznalos.Add(newFelhasznalo);
            _context.SaveChanges();
        }

        // Read (Bejelentkezési adatok ellenőrzése)
        public Felhasznalo? GetFelhasznaloForLogin(string username, string password)
        {
            Felhasznalo? felhasznalo = _context.Felhasznalos
                .FirstOrDefault(u => u.FelhasznaloiNev == username && u.Jelszo == password);
            return felhasznalo;
        }

        // Update (Felhasználói adatok frissítése)
        public void UpdateFelhasznalo(Felhasznalo felhasznalo)
        {
            _context.Felhasznalos.Update(felhasznalo);
            _context.SaveChanges();
        }

        // Delete (Felhasználó törlése)
        public void DeleteFelhasznalo(uint id)
        {
            Felhasznalo? felhasznaloToDelete = _context.Felhasznalos.Find(id);
            if (felhasznaloToDelete != null)
            {
                _context.Felhasznalos.Remove(felhasznaloToDelete);
                _context.SaveChanges();
            }
        }
    }
}
