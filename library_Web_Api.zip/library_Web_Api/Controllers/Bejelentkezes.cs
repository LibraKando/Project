﻿using library_Web_Api.Models;
using System.Linq;

namespace library_Web_Api.Controllers
{
    public class Bejelentkezes
    {
        private LibraryContext _context;

        public Bejelentkezes(LibraryContext context)
        {
            _context = context;
        }

        public string Login(string username, string password)
        {
            Felhasznalo? user = _context.Felhasznalos.FirstOrDefault(u => u.FelhasznaloiNev == username);

            if (user != null && user.Jelszo == password)
            {
                return "Sikeres bejelentkezés";
            }
            else if (user != null)
            {
                return "Hibás jelszó";
            }
            else
            {
                return "Nem található a felhasználó";
            }
        }

    }
}
