﻿using Microsoft.AspNetCore.Mvc;
using library_Web_Api.Models;
using library_Web_Api.Services;


namespace library_Web_Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class KonyvController : ControllerBase
    {

        private readonly KonyvService _konyvService;

        public KonyvController(KonyvService konyvService)
        {
            _konyvService = konyvService;
        }

        // POST: api/Konyv
        [HttpPost]
        public IActionResult AddKonyv([FromBody] Konyv konyv)
        {
            _konyvService.AddKonyv(konyv);
            return CreatedAtAction(nameof(GetKonyvById), new { id = konyv.Id }, konyv);
        }

        // GET: api/Konyv/{id}
        [HttpGet("{id}")]
        public ActionResult<Konyv> GetKonyvById(uint id)
        {
            var konyv = _konyvService.GetKonyvById(id);
            if (konyv == null)
            {
                return NotFound();
            }
            return konyv;
        }

        // GET: api/Konyv
        [HttpGet]
        public ActionResult<IEnumerable<Konyv>> GetAllKonyvek()
        {
            return Ok(_konyvService.GetAllKonyvek());
        }

        // PUT: api/Konyv/{id}
        [HttpPut("{id}")]
        public IActionResult UpdateKonyv(uint id, [FromBody] Konyv konyv)
        {
            if (id != konyv.Id)
            {
                return BadRequest();
            }
            _konyvService.UpdateKonyv(konyv);
            return NoContent();
        }

        // DELETE: api/Konyv/{id}
        [HttpDelete("{id}")]
        public IActionResult DeleteKonyv(uint id)
        {
            var existingKonyv = _konyvService.GetKonyvById(id);
            if (existingKonyv == null)
            {
                return NotFound();
            }
            _konyvService.DeleteKonyv(id);
            return NoContent();
        }
    }
}