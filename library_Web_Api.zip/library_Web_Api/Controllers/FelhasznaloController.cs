﻿using Microsoft.AspNetCore.Mvc;
using library_Web_Api.Models;
using System.Collections.Generic;
using library_Web_Api.Services;

namespace library_Web_Api.Controllers
{

    [Route("api/[controller]")]
    [ApiController]

    public class FelhasznaloController : ControllerBase
    {
        private readonly FelhasznaloService _felhasznaloService;

        public FelhasznaloController(FelhasznaloService felhasznaloService)
        {
            _felhasznaloService = felhasznaloService;
        }

        // POST: api/Felhasznalo
        [HttpPost]
        public IActionResult AddFelhasznalo([FromBody] Felhasznalo newFelhasznalo)
        {
            _felhasznaloService.AddFelhasznalo(newFelhasznalo);
            return CreatedAtAction(nameof(GetFelhasznaloById), new { id = newFelhasznalo.Id }, newFelhasznalo);
        }

        // GET: api/Felhasznalo/{id}
        [HttpGet("{id}")]
        public ActionResult<Felhasznalo> GetFelhasznaloById(uint id)
        {
            var felhasznalo = _felhasznaloService.GetFelhasznaloById(id);
            if (felhasznalo == null)
            {
                return NotFound();
            }
            return felhasznalo;
        }

        // GET: api/Felhasznalo
        [HttpGet]
        public ActionResult<IEnumerable<Felhasznalo>> GetAllFelhasznalok()
        {
            return Ok(_felhasznaloService.GetAllFelhasznalok());
        }

        // PUT: api/Felhasznalo/{id}
        [HttpPut("{id}")]
        public IActionResult UpdateFelhasznalo(uint id, [FromBody] Felhasznalo felhasznalo)
        {
            if (id != felhasznalo.Id)
            {
                return BadRequest();
            }
            _felhasznaloService.UpdateFelhasznalo(felhasznalo);
            return NoContent();
        }

        // DELETE: api/Felhasznalo/{id}
        [HttpDelete("{id}")]
        public IActionResult DeleteFelhasznalo(uint id)
        {
            var existingFelhasznalo = _felhasznaloService.GetFelhasznaloById(id);
            if (existingFelhasznalo == null)
            {
                return NotFound();
            }
            _felhasznaloService.DeleteFelhasznalo(id);
            return NoContent();
        }
    }
}
