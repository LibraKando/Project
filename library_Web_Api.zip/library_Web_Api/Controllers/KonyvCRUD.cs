﻿using library_Web_Api.Models;

namespace library_Web_Api.Controllers
{
    public class KonyvCRUD
    {
        private LibraryContext _context;

        public KonyvCRUD(LibraryContext context)
        {
            _context = context;
        }

        // Create
        public void AddKonyv(Konyv newKonyv)
        {
            _context.Konyvs.Add(newKonyv);
            _context.SaveChanges();
        }

        // Read
        public Konyv? GetKonyvById(uint id)
        {
            Konyv? konyv = _context.Konyvs.Find(id);
            return konyv;
        }

        public IEnumerable<Konyv> GetAllKonyvek()
        {
            List<Konyv> konyvek = _context.Konyvs.ToList();
            return konyvek;
        }

        // Update
        public void UpdateKonyv(Konyv konyv)
        {
            _context.Konyvs.Update(konyv);
            _context.SaveChanges();
        }

        // Delete
        public void DeleteKonyv(uint id)
        {
            Konyv? konyvToDelete = _context.Konyvs.Find(id);
            if (konyvToDelete != null)
            {
                _context.Konyvs.Remove(konyvToDelete);
                _context.SaveChanges();
            }
        }
    }
}
